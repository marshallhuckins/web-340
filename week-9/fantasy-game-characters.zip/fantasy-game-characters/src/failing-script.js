// TODO: Implement this script
console.error("This is an intentional error.");
process.exit(1);
