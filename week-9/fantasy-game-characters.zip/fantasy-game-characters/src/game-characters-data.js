// TODO: Implement this script

const characters = [
  { class: "Warrior", gender: "Male", weapon: "Sword" },
  { class: "Mage", gender: "Female", spell: "Fireball" },
  { class: "Rogue", gender: "Other", ability: "Stealth" },
];

console.log(JSON.stringify(characters));
